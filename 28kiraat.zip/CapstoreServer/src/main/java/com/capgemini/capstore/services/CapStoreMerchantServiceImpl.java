package com.capgemini.capstore.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.dao.ICapStoreCustomerDAO;
import com.capgemini.capstore.dao.ICapStoreMerchantDAO;
import com.capgemini.capstore.dao.ICapStoreProductDAO;

@Service
public class CapStoreMerchantServiceImpl implements ICapStoreMerchantService {

	@Autowired
	ICapStoreMerchantDAO merchantRepo;
	
	@Autowired
	ICapStoreCustomerDAO customerRepo;
	
	@Autowired
	ICapStoreProductDAO prodRepo;
	
	
	@Override
	public void registerMerchant(Merchant merchant) {
		
		merchantRepo.save(merchant);
	}

	@Override
	public void registerCustomer(Customer customer) {
		customerRepo.save(customer);
		
	}

	@Override
	public void registerProduct(Product p) {
		prodRepo.save(p);		
	}

}
