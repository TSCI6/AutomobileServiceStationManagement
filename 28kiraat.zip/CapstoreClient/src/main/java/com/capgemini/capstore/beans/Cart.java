package com.capgemini.capstore.beans;


public class Cart {
	
	


	private int id;
	
	private Customer customer;
	
	private Product product;

	private Merchant merchant;
	
	private int quantity;
	
	private double productPrice;
	
	
	private Promo promo;
	
	private String softDelete;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public Promo getPromo() {
		return promo;
	}

	public void setPromo(Promo promo) {
		this.promo = promo;
	}

	public String getSoftDelete() {
		return softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}
	
	
	@Override
	public String toString() {
		return "Cart [id=" + id + ", customer=" + customer + ", product=" + product + ", merchant=" + merchant
				+ ", quantity=" + quantity + ", productPrice=" + productPrice + ", promo=" + promo + ", softDelete="
				+ softDelete + "]";
	

	}
}
