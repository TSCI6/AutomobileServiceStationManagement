package com.capgemini.capstore.beans;


public class DummyOrder {

	
	private int orderId;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
}
